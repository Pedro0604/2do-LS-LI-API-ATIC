namespace Aseguradora.Aplicacion.ClassUtils;

public class Error
{
    public string? Mensaje { get; set; } = "";
}